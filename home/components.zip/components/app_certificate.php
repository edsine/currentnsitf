<?php
session_start();

$conn = new mysqli('23.94.186.186', 'ensitfco_nuru', '2338@nsitf', 'ensitfco_nsitf');


       $certId  =  $_GET['cert'];

 
            $dd = 1;
            
             $query2 = "UPDATE certificate_request SET processing_status=? where request_id =? ";
        $stmt = $conn->prepare($query2);
        $stmt->bind_param('ss', $dd,  $certId );
        $result = $stmt->execute();
        
        if($result){
            
            
                  $_SESSION['cert_request'] = TRUE;
header("location:../pending_certificates");}