<?php 
session_start();

$conn = new mysqli('23.94.186.186', 'ensitfco_nuru', '2338@nsitf', 'ensitfco_nsitf');



            $cert = $_GET['cert'];
           
   
            $dd = 1;
            
             $query2 = "UPDATE leave_request SET approve_status=? where leaveId =? ";
        $stmt = $conn->prepare($query2);
        $stmt->bind_param('ss', $dd,  $cert );
        $result = $stmt->execute();
        
            header("location:../leave_rquest");
            