<?php 
session_start();


$conn = new mysqli('23.94.186.186', 'ensitfco_nuru', '2338@nsitf', 'ensitfco_nsitf');


    
          
            $cert = $_GET['cert'];
           
   
            $dd = 1;
            
             $query2 = "UPDATE transactions SET approve_status=? where transactionId =? ";
        $stmt = $conn->prepare($query2);
        $stmt->bind_param('ss', $dd,  $cert );
        $result = $stmt->execute();
        
           $_SESSION['payment'] = TRUE;
        
            header("location:../view_payments");
            