﻿<?php
SESSION_start();
session_destroy();
header("location:index");

?> 
