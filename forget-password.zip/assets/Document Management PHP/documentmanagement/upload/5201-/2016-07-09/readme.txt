��� ���� ������ ������

Welcome to the simple documentation system.

This script can be used for contracts and purchases departments, small clinics as well where attachments will be the health reports.
dare to say it can be used for small offices for easy tasks such as income and outcome mail etc.

see how it works in the img folder !

please anyone will improve this script or secure it , enhance it in anyway.. please share the new version of you with me.

thank you

Isma'el (abubasil70@gmail.com)
skypeID : abu_basil