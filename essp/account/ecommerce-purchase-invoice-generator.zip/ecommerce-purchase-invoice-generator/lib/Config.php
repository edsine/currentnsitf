<?php
namespace Phppot;

class Config
{
    const TERMS = 30; // days
}