# Paystack Checkout Form

This is for integrating Paystack payout system for any website using jQuery and PHP.
To get started you need to sign up on [Paystack](https://dashboard.paystack.com) website.
Follow my tutorial on [Meduim](https://medium.com/@stephenjudesuccess/how-to-integrate-paystack-checkout-in-5mins-with-only-html-css-js-84d25ca4d6ef) for more infomation on how to setup Paystack payment.
