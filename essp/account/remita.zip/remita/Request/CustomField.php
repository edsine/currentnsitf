<?php

class CustomField
{
    public $name;

    public $value;

    public $type;
}
?>