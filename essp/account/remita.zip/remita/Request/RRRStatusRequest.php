<?php

class RRRStatusRequest
{

    public $rrr;
}
?>
