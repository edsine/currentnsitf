<?php

class ApplicationUrl
{

    // https://remitademo.net/remita/exapp/api/v1/send/api/echannelsvc/merchant/api/paymentinit
    public static $demoUrl = "https://remitademo.net";

    public static $liveUrl = "https://login.remita.net";

    public static $genRRRpath = "/remita/exapp/api/v1/send/api/echannelsvc/merchant/api/paymentinit";

    public static $rrrStatusPath = "/remita/ecomm/";
}

?>
