<?php

class Credentials
{

    public $url;

    public $merchantId;

    public $apiKey;

    public $serviceTypeId;

    public $orderId;

    public $amount;

    public $apihash;

    public $headers;
}

?>
